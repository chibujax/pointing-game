
Attach users to vote result so that after a wile, it should persist
after vote,
when admin refreshes, he should still see results
same as users


after reveal, voting is ignored at that point until restart


Enter on join does not work

test title
Change session header image

add millewares for server requests
What happens when session is not found

Update readme with readme
Add test
